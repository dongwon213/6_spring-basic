package com.example.board.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TimeMapper {

    String getTime();




}
