CREATE TABLE TBL_OWNER (
                           PROVIDER_ID VARCHAR2(255) PRIMARY KEY,
                           PROVIDER VARCHAR2(50),
                           OWNER_NAME VARCHAR2(100),
                           OWNER_AGE NUMBER,
                           OWNER_LICENCE VARCHAR2(100),
                           OWNER_PHONE_NUMBER VARCHAR2(100),
                           OWNER_ADDRESS VARCHAR2(255),
                           OWNER_JOB VARCHAR2(100),
                           PROFILE_PIC VARCHAR2(255),
                           ROLE VARCHAR2(10)
);

CREATE TABLE TBL_CAR (
                         CAR_ID NUMBER PRIMARY KEY,
                         CAR_NUMBER VARCHAR2(100),
                         CAR_MODEL VARCHAR2(100),
                         CAR_CHARGING_TYPE VARCHAR2(100),
                         PROVIDER_ID VARCHAR2(255),
                         INSURER_ID NUMBER,
                         CURRENT_LOCATION VARCHAR2(200),
                         CURRENT_BATTERY NUMBER,
                         CURRENT_STATUS VARCHAR2(50),
                         FOREIGN KEY (PROVIDER_ID) REFERENCES TBL_OWNER(PROVIDER_ID),
                         FOREIGN KEY (INSURER_ID) REFERENCES TBL_INSURER(INSURER_ID)
);

CREATE TABLE TBL_INSURER (
                             INSURER_ID NUMBER PRIMARY KEY,
                             INSURE_NUMBER VARCHAR2(100),
                             INSURER_NAME VARCHAR2(100),
                             INSURER_PHONE_NUMBER VARCHAR2(100),
                             INSURER_REQUEST VARCHAR2(100)
);

CREATE TABLE TBL_INQUIRY (
                             INQUIRY_ID NUMBER PRIMARY KEY,
                             INQUIRY_TITLE VARCHAR2(200),
                             INQUIRY_CONTENT VARCHAR2(2000),
                             INQUIRY_VIEW NUMBER,
                             INQUIRY_REGISTER_DATE DATE,
                             INQUIRY_UPDATE_DATE DATE,
                             PROVIDER_ID VARCHAR2(255),
                             FOREIGN KEY (PROVIDER_ID) REFERENCES TBL_OWNER(PROVIDER_ID)
);

ALTER TABLE TBL_INQUIRY
    ADD REQUEST_ID NUMBER;

ALTER TABLE TBL_INQUIRY
    ADD CONSTRAINT FK_REQUEST_ID FOREIGN KEY (REQUEST_ID)
        REFERENCES TBL_CHARGING_REQUEST(REQUEST_ID);

CREATE TABLE TBL_COMMENTS (
                              COMMENT_ID NUMBER PRIMARY KEY,
                              INQUIRY_ID NUMBER,
                              PROVIDER_ID VARCHAR2(255),
                              COMMENT_CONTENT VARCHAR2(2000),
                              COMMENT_REGISTER_DATE DATE,
                              COMMENT_UPDATE_DATE DATE,
                              FOREIGN KEY (INQUIRY_ID) REFERENCES TBL_INQUIRY(INQUIRY_ID),
                              FOREIGN KEY (PROVIDER_ID) REFERENCES TBL_OWNER(PROVIDER_ID)
);

CREATE TABLE TBL_FILES (
                           FILE_ID NUMBER PRIMARY KEY,
                           INQUIRY_ID NUMBER,
                           ORIGINAL_FILE_NAME VARCHAR2(200),
                           STORED_FILE_NAME VARCHAR2(200),
                           FILE_SIZE NUMBER,
                           UPLOAD_TIME DATE,
                           FOREIGN KEY (INQUIRY_ID) REFERENCES TBL_INQUIRY(INQUIRY_ID)
);

CREATE TABLE TBL_CHARGING_STATION (
                                      STATION_ID NUMBER PRIMARY KEY,
                                      STATION_ADDRESS VARCHAR2(200),
                                      STATION_PHONE_NUMBER VARCHAR2(100),
                                      STATION_NAME VARCHAR2(100)
);

CREATE TABLE TBL_STATION_CHARGER (
                                     CHARGER_ID NUMBER PRIMARY KEY,
                                     STATION_ID NUMBER,
                                     CAR_CHARGING_TYPE VARCHAR2(100),
                                     CHARGER_STATUS VARCHAR2(50),
                                     FOREIGN KEY (STATION_ID) REFERENCES TBL_CHARGING_STATION(STATION_ID)
);

CREATE TABLE TBL_CHARGING_REQUEST (
                                      REQUEST_ID NUMBER PRIMARY KEY,
                                      PROVIDER_ID VARCHAR2(255),
                                      CAR_ID NUMBER,
                                      CHARGING_PERMIT VARCHAR2(50),
                                      STATION_ID NUMBER,
                                      REQUEST_STATUS VARCHAR2(50),
                                      CHARGING_TIME DATE,
                                      CHARGE_AMOUNT NUMBER,
                                      FOREIGN KEY (PROVIDER_ID) REFERENCES TBL_OWNER(PROVIDER_ID),
                                      FOREIGN KEY (CAR_ID) REFERENCES TBL_CAR(CAR_ID),
                                      FOREIGN KEY (STATION_ID) REFERENCES TBL_CHARGING_STATION(STATION_ID)
);


CREATE TABLE TBL_CHARGING_SESSION (
                                      SESSION_ID NUMBER PRIMARY KEY,
                                      REQUEST_NUMBER NUMBER,
                                      CHARGING_START_TIME DATE,
                                      CHARGING_END_TIME DATE,
                                      CHARGE_AMOUNT NUMBER,
                                      FOREIGN KEY (REQUEST_NUMBER) REFERENCES TBL_CHARGING_REQUEST(REQUEST_ID)
);

CREATE TABLE TBL_DRIVING_INFO (
                                  DRIVING_ID NUMBER PRIMARY KEY,
                                  CAR_ID NUMBER,
                                  START_ADDRESS VARCHAR2(200),
                                  STATION_ID NUMBER,
                                  END_ADDRESS VARCHAR2(200),
                                  START_TIME DATE,
                                  END_TIME DATE,
                                  DRIVING_STATUS VARCHAR2(50),
                                  FOREIGN KEY (CAR_ID) REFERENCES TBL_CAR(CAR_ID),
                                  FOREIGN KEY (STATION_ID) REFERENCES TBL_CHARGING_STATION(STATION_ID)
);

-- 시퀀스 생성
CREATE SEQUENCE SEQ_OWNER_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;


CREATE SEQUENCE SEQ_CAR_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE SEQUENCE SEQ_INSURER_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

drop sequence SEQ_INQUIRY_ID;

CREATE SEQUENCE SEQ_INQUIRY_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE SEQUENCE SEQ_COMMENT_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE SEQUENCE SEQ_FILE_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE SEQUENCE SEQ_STATION_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE SEQUENCE SEQ_CHARGER_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE SEQUENCE SEQ_REQUEST_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE SEQUENCE SEQ_SESSION_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;

CREATE SEQUENCE SEQ_DRIVING_ID
    START WITH 1
    INCREMENT BY 1
    NOCACHE;