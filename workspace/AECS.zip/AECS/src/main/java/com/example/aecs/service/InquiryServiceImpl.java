package com.example.aecs.service;

import com.example.aecs.domain.dto.InquiryDTO;
import com.example.aecs.domain.dto.InquiryDetailDTO;
import com.example.aecs.domain.dto.InquiryListDTO;
import com.example.aecs.domain.oauth.CustomOAuth2User;
import com.example.aecs.mapper.InquiryMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InquiryServiceImpl implements InquiryService {

    private final InquiryMapper inquiryMapper;


    @Override
    public List<InquiryListDTO> getInquiryList(int page, int pageSize) {

        int startRow = (page - 1) * pageSize;
        int endRow = page * pageSize;

        return inquiryMapper.selectAll(startRow, endRow);
    }

    @Override
    public int getInquiryListCount() {
        return inquiryMapper.countInquiry();
    }

    @Override
    public void saveInquiry(InquiryDTO inquiry, List<MultipartFile> files) {
        long inquiryId = inquiryMapper.getSeq();
        inquiry.setInquiryId((int) inquiryId);
        inquiryMapper.saveInquiry(inquiry);  // 게시글 정보 저장

//        saveFile(boardId, files);
    }

    @Override
    public InquiryDetailDTO getInquiryById(int inquiryId, CustomOAuth2User customOAuth2User) {

        InquiryDetailDTO inquiry = inquiryMapper.selectInquiryDetail(inquiryId);

        // 조회 수 상승을 결정할 if
        if(customOAuth2User == null || !customOAuth2User.getProviderId().equals(inquiry.getProviderId())){
            // 조회 수가 플러스 1이 되는 update 쿼리문
            inquiryMapper.plusView(inquiryId);
        }
        return inquiry;
    }

    @Override
    public InquiryDetailDTO goUpdateInquiry(int inquiryId) {
        return null;
    }
}
