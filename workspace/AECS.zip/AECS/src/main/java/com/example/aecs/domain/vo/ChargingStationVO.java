package com.example.aecs.domain.vo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.stereotype.Component;

@Component
@Getter
@ToString
@NoArgsConstructor
public class ChargingStationVO {
    private int stationId;
    private String stationAddress;
    private String stationPhoneNumber;
    private String stationName;
}
