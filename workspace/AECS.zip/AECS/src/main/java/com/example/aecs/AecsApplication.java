package com.example.aecs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AecsApplication {

    public static void main(String[] args) {
        SpringApplication.run(AecsApplication.class, args);
    }

}
