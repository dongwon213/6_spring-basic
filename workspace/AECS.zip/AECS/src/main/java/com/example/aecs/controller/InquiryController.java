package com.example.aecs.controller;

import com.example.aecs.domain.dto.InquiryListDTO;
import com.example.aecs.domain.dto.OwnerDTO;
import com.example.aecs.domain.oauth.CustomOAuth2User;
import com.example.aecs.domain.vo.OwnerVO;
import com.example.aecs.mapper.OwnerMapper;
import com.example.aecs.service.InquiryService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/inquiry")
@RequiredArgsConstructor
public class InquiryController {

    private final OwnerMapper ownerMapper;
    private final InquiryService inquiryService;

    @GetMapping("/list")
    public String list(@RequestParam(value = "pageNo", defaultValue = "1") int pageNo,
                       @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
                       Model model){

        int totalBoards = inquiryService.getInquiryListCount();
        int totalPages = (int) Math.ceil((double)totalBoards/pageSize);

        List<InquiryListDTO> boards = inquiryService.getInquiryList(pageNo, pageSize);

        int pageGroupSize = 5;
        int startPage = ((pageNo - 1) / pageGroupSize) * pageGroupSize + 1;
        int endPage = Math.min(startPage + pageGroupSize - 1, totalPages);

        model.addAttribute("boards", boards);
        model.addAttribute("currentPage", pageNo);
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("totalPages", totalPages);

        model.addAttribute("startPage", startPage);
        model.addAttribute("endPage", endPage);

        return "list";

    }

    @GetMapping("/join")
    public String join(){
        return "join";
    }

    @PostMapping("/join")
    public String join(@RequestParam String userType,
                       @RequestParam String ownerPhone,
                       @RequestParam String address,
                       @RequestParam String licence,
                       @AuthenticationPrincipal CustomOAuth2User customOAuth2User){

        OwnerDTO ownerDTO = ownerMapper.findByProviderId(customOAuth2User.getProviderId());

        ownerDTO.setJob(userType);
        ownerDTO.setRole("basic");
        ownerDTO.setPhoneNumber(ownerPhone);
        ownerDTO.setAddress(address);
        ownerDTO.setLicence(licence);

        ownerMapper.insertNewOwner(OwnerVO.toEntity(ownerDTO));

        return "redirect:/list";
    }

    @GetMapping("login")
    public String goForm(HttpSession session){

        session.invalidate();

        return "loginForm";
    }





}
