package com.example.aecs.domain.vo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.stereotype.Component;

@Component
@Getter
@ToString
@NoArgsConstructor
public class CarVO {
    private int carId;
    private String carNumber;
    private String carModel;
    private String carChargingType;
    private String providerId;
    private int insurerId;
    private String currentLocation;
    private int currentBattery;
    private String currentStatus;
}
