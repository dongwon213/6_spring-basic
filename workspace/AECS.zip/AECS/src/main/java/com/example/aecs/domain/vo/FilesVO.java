package com.example.aecs.domain.vo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.stereotype.Component;

@Component
@Getter
@ToString
@NoArgsConstructor
public class FilesVO {
    private int fileId;
    private int inquiryId;
    private String originalFileName;
    private String storedFileName;
    private int fileSize;
    private String uploadTime;
}
