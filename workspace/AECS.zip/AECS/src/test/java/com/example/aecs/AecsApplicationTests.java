package com.example.aecs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AecsApplicationTests {

    @Test
    void contextLoads() {
    }

}
